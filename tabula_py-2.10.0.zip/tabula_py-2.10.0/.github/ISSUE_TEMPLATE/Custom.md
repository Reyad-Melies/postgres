---
name: Question
about: The issue tracker is not for questions. Please use Stack Overflow or other
  resources for help writing tabula-py code.

---

THE ISSUE TRACKER IS NOT FOR QUESTIONS.

DO NOT CREATE A NEW ISSUE TO ASK A QUESTION.

You can use GitHub discussions for question instead. [Search the GH discussion](https://github.com/chezou/tabula-py/discussions?discussions_q=is%3Aopen), or [create a new discussion](https://github.com/chezou/tabula-py/discussions/new/choose).
